# Type: Integer




_An integer_



URI: [xsd:integer](http://www.w3.org/2001/XMLSchema#integer)

* [base](https://w3id.org/linkml/base): int

* [uri](https://w3id.org/linkml/uri): xsd:integer









## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/linkml/examples/personinfo




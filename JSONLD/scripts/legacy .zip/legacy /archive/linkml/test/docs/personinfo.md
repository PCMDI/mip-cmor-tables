# personinfo

None

URI: https://w3id.org/linkml/examples/personinfo

